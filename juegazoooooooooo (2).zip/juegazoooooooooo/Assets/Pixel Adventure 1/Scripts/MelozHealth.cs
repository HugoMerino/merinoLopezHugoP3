using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MelozHealth : MonoBehaviour
{
    private int maxHealth = 1;
    public GameObject Meloz;
    Vector2 positionInitial;
    public int health { get { return currentHealth; }}
    public int currentHealth;
    void Start()
    {
        currentHealth = maxHealth;
        positionInitial = Meloz.transform.position;
    }

    
    public void ChangeHealth(int currentHealth)
    {
        Meloz.transform.position = positionInitial;
    }
}
