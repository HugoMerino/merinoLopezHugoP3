using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageZone : MonoBehaviour
{
    public GameObject Meloz;
    Vector2 positionInitial;

    void start()
    {
        positionInitial=Meloz.transform.position;
    }
    void OnTriggerStay2D(Collider2D other)
    {
        MelozHealth controller = other.GetComponent<MelozHealth>();

        if (controller != null)
        {
            controller.ChangeHealth(0);
            Meloz.transform.position=positionInitial;
        }
    }
}
