using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    public GameObject Meloz;




    void Update()
    {
        Vector3 position = transform.position;
        position.x = Meloz.transform.position.x;
        position.y = Meloz.transform.position.y;
        transform.position = position;



    }
}